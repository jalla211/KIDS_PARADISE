<?php

$conn = mysqli_connect(
"localhost",
"root",
"",
"kids_paradise_db"
);

if(!$conn){
    die("Database connection failed");
}

?>