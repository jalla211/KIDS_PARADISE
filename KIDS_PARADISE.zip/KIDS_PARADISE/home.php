<?php
session_start();

include "config/database.php";


$cart_count = 0;


if(isset($_SESSION['user_id'])){


    $user_id = $_SESSION['user_id'];


    $cart_result = mysqli_query(
        $conn,
        "SELECT SUM(quantity) AS total 
         FROM cart 
         WHERE user_id='$user_id'"
    );


    $cart_data = mysqli_fetch_assoc($cart_result);


    if($cart_data['total'] != NULL){

        $cart_count = $cart_data['total'];

    }

}

?>

<!DOCTYPE html>
<html>
<head>
<title>KIDS PARADISE</title>

<style>

/* ===== GLOBAL ===== */
body{
    font-family:Segoe UI;
    margin:0;
    background:#f4f6fb;
}

/* ===== NAVBAR ===== */
.navbar{
    background:#1565C0;
    color:white;
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:10px 18px;
    position:sticky;
    top:0;
}

.logo{
    font-size:18px;
    font-weight:bold;
}

/* MENU */
.menu{
    display:flex;
    gap:12px;
    align-items:center;
}

.menu a{
    color:white;
    text-decoration:none;
    font-size:14px;
}

/* dropdown */
.dropdown{
    position:relative;
}

.dropdown-content{
    display:none;
    position:absolute;
    background:white;
    min-width:140px;
    top:25px;
    border-radius:8px;
    overflow:hidden;
    box-shadow:0 5px 12px rgba(0,0,0,0.2);
}

.dropdown-content a{
    display:block;
    padding:8px;
    color:black;
    font-size:13px;
}

.dropdown:hover .dropdown-content{
    display:block;
}

/* SEARCH */
.search input{
    padding:6px 10px;
    border-radius:20px;
    border:none;
    outline:none;
    width:160px;
    font-size:13px;
}

/* RIGHT */
.right{
    display:flex;
    gap:8px;
    align-items:center;
}

.cart{
    color:white;
    font-size:14px;
    text-decoration:none;
}

/* LOGIN / LOGOUT BUTTONS */
.btn{
    padding:5px 10px;
    border-radius:15px;
    font-size:12px;
    text-decoration:none;
}

.login{
    background:#4CAF50;
    color:white;
}

.logout{
    background:#f44336;
    color:white;
}

/* ===== PRODUCTS GRID (SMALLER CARDS) ===== */
.products{
    display:grid;
    grid-template-columns:repeat(6, 1fr);
    gap:15px;
    padding:20px;
}

/* CARD EVEN SMALLER */
.card{
    width:150px;
    background:white;
    border-radius:10px;
    overflow:hidden;
    box-shadow:0 3px 8px rgba(0,0,0,0.15);
    transition:0.3s;
}

.card:hover{
    transform:translateY(-5px);
}

.card img{

    width:150px;
    height:120px;

    object-fit:cover;

}

.card h4{

    margin:8px;
    font-size:13px;

}


.card p{

    margin:8px;
    font-size:11px;
    height:35px;
    overflow:hidden;

}


.price{

    margin:8px;
    font-size:13px;
    font-weight:bold;
    color:#1565C0;

}


.stock{

    margin:8px;
    font-size:11px;

}

.btn-cart{

    display:block;
    width:100%;
    padding:7px;

    background:#1565C0;
    color:white;

    text-align:center;
    text-decoration:none;

    font-size:11px;

}

.btn-cart:hover{
    background:#0D47A1;
}

</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">

    <div class="logo">🧸 KIDS PARADISE</div>

    <div class="menu">

        <a href="home.php">Home</a>

        <!-- CATEGORIES -->
        <div class="dropdown">
            <a href="#">Categories ▾</a>
            <div class="dropdown-content">

                <?php
                $cat = mysqli_query($conn,"SELECT * FROM categories");
                while($c = mysqli_fetch_assoc($cat)){
                ?>
                    <a href="home.php?category=<?= $c['id'] ?>">
                        <?= $c['name'] ?>
                    </a>
                <?php } ?>

            </div>
        </div>

        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
        <a href="my_orders.php" style="color:white;">
Track My Orders
</a>

    </div>

    <div class="search">
        <input type="text" placeholder="Search...">
    </div>

    <div class="right">

        <a href="cart.php" class="cart">

🛒 Cart (<?= $cart_count ?>)

</a>

        <?php if(isset($_SESSION['user_id'])) { ?>
            <a href="login.php" class="btn login">Login</a>
            <a href="logout.php" class="btn logout">Logout</a>
        <?php } else { ?>
            <a href="login.php" class="btn login">Login</a>
        <?php } ?>

    </div>

</div>

<!-- PRODUCTS -->
<div class="products">

<?php
$sql = "SELECT * FROM products";

if(isset($_GET['category'])){
    $cat_id = $_GET['category'];
    $sql .= " WHERE category_id=$cat_id";
}

$result = $conn->query($sql);

while($row = $result->fetch_assoc()){
?>

<div class="card">

    <img src="uploads/<?= $row['image'] ?>">

    <h4><?= $row['name'] ?></h4>

    <p><?= $row['description'] ?></p>

    <div class="price">$<?= $row['price'] ?></div>

    <div class="stock">Stock: <?= $row['stock'] ?></div>

   <a href="add_to_cart.php?id=<?= $row['id'] ?>" class="btn-cart">
    Add to Cart
</a>

</div>

<?php } ?>

</div>

</body>
</html>